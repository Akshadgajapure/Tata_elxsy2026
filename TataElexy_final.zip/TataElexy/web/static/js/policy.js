/* QoS Policies page: renders the policy the controller actually holds. */
(function () {
  const { f, na, isNil, esc, dl, badge, clock, snapRows, getJSON } = window.QOSUI;
  const $ = s => document.querySelector(s);
  async function load() {
    let p = null;
    try { p = await getJSON('/api/policy'); } catch (e) { return; }
    const body = $('#policy-table tbody'), prev = $('#prev-table tbody');
    if (!p) {
      body.innerHTML = '<tr><td colspan="8" class="muted">No policy generated yet. The controller needs at least 1 Mbit/s of observed traffic.</td></tr>';
      $('#pol-meta').innerHTML = na('N/A — no policy yet'); return;
    }
    $('#pol-meta').innerHTML = dl([
      ['Version', `v${p.version}`], ['Timestamp', clock(p.timestamp)], ['Reason', esc(p.reason || 'N/A')],
      ['Capacity basis', `${f(p.capacity_mbps, 1)} Mbit/s <span class="badge warn">PLACEHOLDER</span>`],
      ['Backend', badge('DRY RUN', 'warn') + ' not applied to tc'],
      ['Intent modifier', p.intent_device ? esc(p.intent_device) + ' <span class="muted">(recorded; no re-weighting yet)</span>' : 'none'],
      ['Safety result', p.safety.ok ? badge('PASS', 'ok') + ' ' + esc(p.safety.detail) : badge('FAIL', 'bad') + ' ' + esc(p.safety.detail)]]);
    $('#pol-note').textContent = p.note;
    body.innerHTML = snapRows(p.classes, true);
    const pv = p.previous;
    $('#prev-meta').innerHTML = pv ? dl([['Version', `v${pv.version}`], ['Timestamp', clock(pv.timestamp)], ['Reason', esc(pv.reason)],
      ['Capacity basis', `${f(pv.capacity_mbps, 1)} Mbit/s`], ['Intent modifier', pv.intent_device ? esc(pv.intent_device) : 'none']]) : na('N/A — no earlier policy version yet');
    prev.innerHTML = pv ? snapRows(pv.classes, false) : '';
  }

  async function allocation() {
    let fr = null;
    try { fr = (await getJSON('/api/metrics')).latest; } catch (e) { return; }
    const a = fr && fr.allocation, body = $('#alloc-table tbody');
    if (!a) { body.innerHTML = '<tr><td colspan="7" class="muted">N/A — no allocation computed yet (needs a capacity estimate).</td></tr>'; $('#alloc-notes').textContent = ''; return; }
    body.innerHTML = Object.entries(a.classes).map(([k, c]) => `<tr><td>${window.QOSUI.tag(k)}</td><td class="r num">${f(c.demand_mbps, 2)}</td><td class="r num">${f(c.guaranteed_mbps, 2)}</td><td class="r num">${f(c.target_mbps, 2)}</td><td class="r num"><b>${f(c.rate_mbps, 2)}</b></td><td class="r num">${f(c.ceil_mbps, 2)}</td><td class="muted wrap">${esc(c.reasons.join(', '))}</td></tr>`).join('');
    const notes = [...a.notes, ...a.stability_notes.map(n => 'stability: ' + n)];
    $('#alloc-notes').textContent = (a.infeasible_minimums ? 'Minimums could not all be met. ' : '') + (notes.join(' · ') || 'No allocation or stability notes.');
  }
  load(); allocation(); setInterval(load, 2000); setInterval(allocation, 2000);
})();
