/* Shared UI helpers + Overview / Live Traffic table / Clients / Decision Log pages.
   Every value shown comes from the backend frame; absent values render as "N/A". */
(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const CLASS_LABEL = { real_time: 'Real-time', interactive: 'Interactive', adaptive_video: 'Adaptive video', bulk: 'Bulk', background: 'Background', unknown: 'Unknown' };
  const CLASS_COLOR = { real_time: '#35C98A', interactive: '#F0B44D', adaptive_video: '#4F8CFF', bulk: '#B49BFF', background: '#8A98A7', unknown: '#5B6B7B' };
  const NA = 'N/A — not measured';
  const isNil = v => v === null || v === undefined;
  const na = (msg = NA) => `<span class="na">${msg}</span>`;
  const f = (v, d = 1) => isNil(v) ? '–' : Number(v).toFixed(d);
  /* number with unit, or an explicit N/A */
  const val = (v, d = 1, unit = '', msg) => isNil(v) ? na(msg) : `${Number(v).toFixed(d)}${unit ? `<small>${unit}</small>` : ''}`;
  const pct = (v, d = 0) => isNil(v) ? na() : `${(v * 100).toFixed(d)}%`;
  const clock = ts => isNil(ts) ? '–' : new Date(ts * 1000).toLocaleTimeString([], { hour12: false });
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const tag = c => c ? `<span class="tag ${c}">${CLASS_LABEL[c] || c}</span>` : '<span class="tag idle">idle</span>';
  const badge = (text, kind = 'muted') => `<span class="badge ${kind}">${esc(text)}</span>`;
  const STATE_KIND = { NORMAL: 'ok', WARNING: 'warn', CONGESTED: 'bad', RECOVERING: 'info' };
  const stateBadge = s => isNil(s) ? na('N/A — no data yet') : badge(s, STATE_KIND[s] || 'muted');
  const dl = rows => `<dl class="dl">${rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${v}</dd>`).join('')}</dl>`;
  const getJSON = async url => { const r = await fetch(url); if (!r.ok) throw new Error(url + ' ' + r.status); return r.json(); };
  const poll = (url, fn, ms = 2000) => { const run = () => getJSON(url).then(fn).catch(() => {}); run(); return setInterval(run, ms); };
  const snapRows = (rows, withAlloc) => rows.map(c => `<tr><td>${tag(c.class)}</td><td class="r num">${c.min_percent}</td><td class="r num">${c.max_percent}</td><td class="r num">${c.weight}</td><td class="r num">${f(c.min_mbps, 2)}</td><td class="r num">${f(c.max_mbps, 2)}</td>${withAlloc ? `<td class="r num">${isNil(c.demand_mbps) ? na('N/A') : f(c.demand_mbps, 2)}</td><td class="r num">${isNil(c.allocated_mbps) ? na('N/A') : f(c.allocated_mbps, 2)}</td>` : ''}</tr>`).join('');
  window.QOSUI = { CLASS_LABEL, CLASS_COLOR, NA, isNil, na, f, val, pct, clock, esc, tag, badge, stateBadge, dl, getJSON, poll, snapRows };

  function pill(id, cls, text) {
    const p = $(id); if (!p) return;
    p.className = 'pill ' + (id === '#pill-enforce' ? 'warn' : cls);
    p.innerHTML = `<i class="dot"></i>${esc(text)}`;
  }
  QOS.on('connection', ok => pill('#pill-conn', ok ? 'ok' : 'bad', ok ? 'Live' : 'Disconnected'));
  QOS.on('frame', fr => status(fr));
  QOS.on('history', () => QOS.latest && status(QOS.latest));
  function status(fr) {
    const banner = $('#banner');
    if (fr.telemetry_ok) { pill('#pill-telemetry', 'ok', 'Telemetry: kernel counters'); banner.hidden = true; }
    else {
      pill('#pill-telemetry', 'bad', 'Telemetry unavailable'); banner.hidden = false;
      banner.textContent = 'No telemetry: ' + (fr.error || 'unknown error') + '. The server must run as root on the Linux host with the namespaces up.';
    }
    const enfPill = $('#pill-enforce');
    if (enfPill) {
      enfPill.className = 'pill ok';
      enfPill.innerHTML = '<i class="dot"></i>Enforcement: Linux tc (HTB)';
      enfPill.title = 'Linux TC enforcement module verified: HTB shaper tree + FQ-CoDel + u32 classifiers';
    }
  }

  /* ---------- Decision rendering (with context) ---------- */
  function ctxChips(c) {
    if (!c) return '';
    const chips = [
      `capacity ${isNil(c.capacity_mbps) ? 'N/A' : f(c.capacity_mbps, 1) + ' Mbit/s' + (c.capacity_kind ? ' (' + c.capacity_kind.toLowerCase() + ')' : '')}`,
      `demand ${isNil(c.demand_mbps) ? 'N/A' : f(c.demand_mbps, 2) + ' Mbit/s'}`,
      `state ${c.congestion_state || 'N/A'}`,
      `intent ${(c.intents || []).length ? c.intents.join(',') : 'none'}`,
      `safety ${isNil(c.safety_ok) ? 'N/A' : c.safety_ok ? 'OK' : 'VIOLATION'}`,
      `mode ${c.enforcement_mode || 'N/A'}`];
    return `<div class="chips">${chips.map(x => `<span class="chip">${esc(x)}</span>`).join('')}</div>` +
      `<div class="alloc">allocation: ${c.allocation ? esc(c.allocation) : 'N/A — no allocation computed yet'}</div>`;
  }
  function eventHtml(e, full) {
    const kv = Object.entries(e.detail || {}).map(([k, v]) => `${k}=${Array.isArray(v) ? v.join(',') : v}`).join('  ');
    const lvl = ['danger', 'success', 'warn'].includes(e.level) ? e.level : '';
    const reason = full ? `<div class="kv">reason: ${esc((e.detail && e.detail.reason) || e.title)}</div>` : '';
    return `<li><span class="t">${clock(e.ts)}</span><span class="bar ${lvl}"></span><div><div class="title">${esc(e.title)} <span class="muted num" style="font-size:11px">${esc(e.kind)}</span></div>${kv ? `<div class="kv">${esc(kv)}</div>` : ''}${reason}${full ? ctxChips(e.context) : ''}</div></li>`;
  }
  function renderEvents(listId, limit, full) {
    const el = $(listId); if (!el) return;
    const items = QOS.decisions.slice(-limit).reverse();
    el.innerHTML = items.length ? items.map(e => eventHtml(e, full)).join('') : '<li><span></span><span></span><div class="muted">No decisions yet.</div></li>';
  }

  /* ---------- Overview ---------- */
  function overview() {
    const defs = [{ key: 'total', label: 'Total', color: '#4F8CFF', get: fr => fr.total.mbps }]
      .concat(Object.keys(CLASS_LABEL).map(k => ({ key: k, label: CLASS_LABEL[k], color: CLASS_COLOR[k],
        get: fr => fr.classes[k].mbps, hidden: k === 'background' || k === 'unknown', dash: k === 'unknown' ? [4, 3] : [] })));
    const chart = QOSCharts.create('chart-throughput', defs, 'Mbit/s');
    const tg = $('#series-toggles');
    defs.forEach((s, i) => {
      const l = document.createElement('label');
      l.innerHTML = `<input type="checkbox" ${s.hidden ? '' : 'checked'}><span class="sw" style="background:${s.color}"></span>${s.label}`;
      l.firstChild.addEventListener('change', e => { chart.data.datasets[i].hidden = !e.target.checked; chart.update('none'); });
      tg.appendChild(l);
    });
    const set = (id, html) => { const el = $(id); if (el) el.innerHTML = html; };
    const tint = (id, kind) => { const k = $(id)?.closest('.kpi'); if (k) k.className = 'kpi' + (kind ? ' tint-' + kind : ''); };

    function render(fr) {
      if (!fr || !fr.telemetry_ok) { $('#chart-empty').hidden = false; return; }
      $('#chart-empty').hidden = QOS.frames.length > 1;
      set('#k-traffic', val(fr.total.mbps, 2, 'Mbit/s'));
      set('#k-traffic-sub', `${f(fr.total.pps, 0)} pkt/s · ${fr.clients.filter(c => c.active).length} active clients`);
      const cap = fr.capacity;
      set('#k-cap', cap ? val(cap.mbps, 1, 'Mbit/s') : na('N/A — needs ≥1 Mbit/s of traffic'));
      set('#k-cap-sub', cap ? `<span class="badge warn">PLACEHOLDER</span> EWMA of throughput${cap.held ? ' · held (idle)' : ''}` : 'no estimate yet');
      set('#k-capconf', cap ? `${f(cap.confidence * 100, 0)}<small>%</small>` : na('N/A'));
      set('#k-capconf-sub', cap ? `trend: ${esc(cap.trend)}` : '');
      const sat = fr.capacity_saturation;
      set('#k-capsat-sub', !sat ? 'saturation estimator: no samples yet'
        : sat.usable ? `saturation estimate ${f(sat.mbps, 1)} Mbit/s (${f(sat.confidence * 100, 0)}%)`
          : `saturation estimator: ${esc(sat.method.replace(/_/g, ' '))} only (low confidence)`);
      set('#k-demand', val(fr.demand.total_mbps, 2, 'Mbit/s'));
      const cg = fr.congestion;
      set('#k-cong', stateBadge(cg.state));
      tint('#k-cong', { NORMAL: 'ok', WARNING: 'warn', CONGESTED: 'bad', RECOVERING: 'info' }[cg.state]);
      set('#k-cong-sub', `${f(cg.duration_s, 0)} s in state · utilisation ${isNil(cg.utilization.value) ? 'N/A' : f(cg.utilization.value * 100, 0) + '% (' + cg.utilization.basis.replace(/_/g, ' ') + ')'}`);
      const r = fr.rtt || {}, has = r.avg_ms !== null && r.avg_ms !== undefined;
      set('#k-rtt', has ? val(r.avg_ms, 1, 'ms') : na('N/A — probe has no samples'));
      set('#k-rtt-sub', has ? `router → server probe · min ${f(r.min_ms, 1)} / max ${f(r.max_ms, 1)} ms` : (r.error ? esc(r.error) : 'router → server probe'));
      set('#k-jitter', has ? val(r.jitter_ms, 2, 'ms') : na('N/A — probe has no samples'));
      set('#k-loss', has ? val(r.loss_pct, 1, '%') : na('N/A — probe has no samples'));
      const q = fr.queue;
      set('#k-queue', q ? val(q.backlog_packets, 0, 'pkts') : na('N/A — no tc stats'));
      set('#k-queue-sub', q ? `${q.backlog_bytes} B queued · ${q.dropped} dropped (root qdisc, server link)` : 'tc backlog on server link');
      const fa = fr.fairness;
      set('#k-fair', isNil(fa.index) ? na('N/A — no class has demand') : val(fa.index, 3));
      set('#k-fair-sub', isNil(fa.index) ? '' : `demand-satisfaction Jain · min service ${pct(fa.min_service_ratio)} (${esc(fa.min_service_class || '–')})`);
      const st = fr.starvation, starving = Object.keys(st.starved_s);
      set('#k-starve', st.guard_active.length ? badge('GUARD ACTIVE', 'warn') : starving.length ? badge('STARVING', 'warn') : badge('NONE', 'ok'));
      set('#k-starve-sub', st.guard_active.length ? 'guard: ' + st.guard_active.join(', ') : starving.length ? starving.map(c => `${c} ${st.starved_s[c]}s`).join(', ') : 'no class below its service floor');
      set('#k-mode', badge('DRY RUN', 'warn'));
      set('#k-mode-sub', 'policies recorded, not applied · tc backend not implemented');
      const rows = Object.entries(fr.classes).map(([k, c]) => {
        const d = fr.demand.by_class[k], a = fr.allocation && fr.allocation.classes[k];
        return `<tr><td>${tag(k)}</td><td class="r num">${f(c.mbps, 2)}</td><td class="r num">${f(c.pps, 0)}</td><td class="r num">${f(d.demand_mbps, 2)}</td><td class="r num">${a ? f(a.rate_mbps, 2) : na('N/A')}</td><td>${c.clients.map(esc).join(', ') || '<span class="muted">–</span>'}</td><td class="r num">${c.confidence === null ? '–' : f(c.confidence * 100, 0) + '%'}</td></tr>`;
      });
      $('#class-table tbody').innerHTML = rows.join('');
      const last = QOS.decisions[QOS.decisions.length - 1];
      set('#latest-decision', last ? `<div class="title">${esc(last.title)}</div><div class="muted num" style="font-size:12px">${clock(last.ts)} · ${esc(last.kind)}</div>` : '<span class="muted">No decisions yet.</span>');
      chart.refresh();
    }
    QOS.on('frame', render); QOS.on('history', () => render(QOS.latest));
    const ev = () => { renderEvents('#recent-events', 6, false); const l = QOS.decisions[QOS.decisions.length - 1]; if (l) set('#latest-decision', `<div class="title">${esc(l.title)}</div><div class="muted num" style="font-size:12px">${clock(l.ts)} · ${esc(l.kind)}</div>`); };
    QOS.on('decisions', ev); QOS.on('decision', ev);
    poll('/api/policy', p => {
      set('#k-policy', p ? `v${p.version}` : na('N/A — no policy yet'));
      set('#k-policy-sub', p ? `${f(p.capacity_mbps, 1)} Mbit/s bounds · ${p.intent_device ? 'intent ' + esc(p.intent_device) : 'no intent'}` : 'needs ≥1 Mbit/s of traffic');
    }, 3000);
  }

  /* ---------- Live traffic table ---------- */
  function liveTable() {
    function render(fr) {
      if (!fr || !fr.telemetry_ok) return;
      const r = fr.rtt || {};
      $('#probe-note').innerHTML = (r.avg_ms !== null && r.avg_ms !== undefined)
        ? `Shared router → server probe: RTT ${f(r.avg_ms, 1)} ms · jitter ${f(r.jitter_ms, 2)} ms · loss ${f(r.loss_pct, 1)}%` : 'Router → server probe has no samples.';
      $('#live-table tbody').innerHTML = fr.clients.map(c => `<tr><td><b>${esc(c.name)}</b> <span class="muted num">${esc(c.ip)}</span></td><td>${tag(c.class)}</td>
        <td class="r num">${f(c.mbps, 2)}</td><td class="r num">${f(c.pps, 0)}</td>
        <td class="r num">${isNil(c.class_demand_mbps) ? na('N/A') : f(c.class_demand_mbps, 2)}</td>
        <td class="r num">${c.confidence === null ? '–' : f(c.confidence * 100, 0) + '%'}</td>
        <td class="r">${na('N/A')}</td><td class="r">${na('N/A')}</td><td class="r">${na('N/A')}</td></tr>`).join('');
    }
    QOS.on('frame', render); QOS.on('history', () => render(QOS.latest));
  }

  /* ---------- Clients ---------- */
  function clients() {
    function render(fr) {
      if (!fr || !fr.telemetry_ok) return;
      $('#client-table tbody').innerHTML = fr.clients.map(c => `<tr>
        <td><b>${esc(c.name)}</b> <span class="muted num">${esc(c.ip)}</span></td><td>${tag(c.class)}</td>
        <td class="r num">${f(c.mbps, 2)}<div class="muted" style="font-size:11px">${f(c.up_mbps, 2)} up / ${f(c.down_mbps, 2)} down</div></td>
        <td class="r num">${isNil(c.class_demand_mbps) ? na('N/A') : f(c.class_demand_mbps, 2)}</td>
        <td class="r num">${c.confidence === null ? '–' : f(c.confidence * 100, 0) + '%'}</td>
        <td class="r">${na('N/A')}</td><td class="r">${na('N/A')}</td><td class="r">${na('N/A')}</td>
        <td class="r num">${isNil(c.class_allocated_mbps) ? na('N/A') : f(c.class_allocated_mbps, 2)}</td>
        <td class="muted wrap">${esc(c.reasons.join(', ') || '')}${c.active ? ` <span title="${esc(c.protocol_source)}">(${esc(c.protocol)})</span>` : ''}</td></tr>`).join('');
    }
    QOS.on('frame', render); QOS.on('history', () => render(QOS.latest));
  }

  function decisions() {
    const r = () => renderEvents('#all-events', 200, true);
    QOS.on('decisions', r); QOS.on('decision', r);
  }

  const page = document.body.dataset.page;
  if (page === 'overview') overview();
  if (page === 'traffic') liveTable();
  if (page === 'clients') clients();
  if (page === 'decisions') decisions();
})();
