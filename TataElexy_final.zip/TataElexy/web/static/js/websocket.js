/* Single WebSocket client. The browser never generates data: it only renders
   what the backend emits (metrics_update, decision, history, decisions). */
(function () {
  const listeners = {};
  const QOS = window.QOS = {
    frames: [], latest: null, decisions: [], connected: false,
    on(ev, fn) { (listeners[ev] = listeners[ev] || []).push(fn); },
    emit(ev, d) { (listeners[ev] || []).forEach(fn => fn(d)); },
  };
  const socket = io({ transports: ['websocket', 'polling'] });
  socket.on('connect', () => { QOS.connected = true; QOS.emit('connection', true); });
  socket.on('disconnect', () => { QOS.connected = false; QOS.emit('connection', false); });
  socket.on('history', list => {
    QOS.frames = list.slice(-120);
    if (QOS.frames.length) QOS.latest = QOS.frames[QOS.frames.length - 1];
    QOS.emit('history', QOS.frames);
  });
  socket.on('decisions', list => { QOS.decisions = list; QOS.emit('decisions', list); });
  socket.on('decision', e => { QOS.decisions.push(e); if (QOS.decisions.length > 500) QOS.decisions.shift(); QOS.emit('decision', e); });
  socket.on('metrics_update', f => {
    QOS.latest = f;
    if (f.telemetry_ok) { QOS.frames.push(f); if (QOS.frames.length > 120) QOS.frames.shift(); }
    QOS.emit('frame', f);
  });
})();
