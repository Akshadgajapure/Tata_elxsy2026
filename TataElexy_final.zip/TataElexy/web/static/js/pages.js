/* Intent, Congestion, Safety, Rollback, Experiments and System pages.
   All data is fetched from backend APIs / frames; nothing is generated here. */
(function () {
  const U = window.QOSUI, { f, na, isNil, esc, dl, badge, stateBadge, clock, getJSON, poll, tag, pct } = U;
  const $ = (s, r = document) => r.querySelector(s);
  const page = document.body.dataset.page;
  const mmss = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  const STATUS_KIND = { active: 'ok', expired: 'muted', cancelled: 'warn', replaced: 'warn' };

  /* ---------------- Intent ---------------- */
  function intent() {
    const err = $('#intent-error');
    function render(v) {
      $('#intent-effect').textContent = v.effect;
      const body = $('#active-intents tbody');
      body.innerHTML = v.active.length ? v.active.map(i => `<tr><td><b>${esc(i.label)}</b></td><td>${esc(i.target)}</td><td>${tag(i.traffic_class)}</td>
        <td>${badge('ACTIVE', 'ok')}</td><td class="r num">${mmss(i.remaining_s)}</td><td class="num">${clock(i.expires_ts)}</td>
        <td>${i.in_policy ? 'recorded in current policy' : na('not yet in a policy (needs traffic)')}</td>
        <td class="r"><button class="btn danger" data-cancel="${esc(i.device_id)}">Cancel</button></td></tr>`).join('')
        : '<tr><td colspan="8" class="muted">No active intent. Normal policy is in effect.</td></tr>';
      body.querySelectorAll('[data-cancel]').forEach(b => b.addEventListener('click', () => post('/api/intent/cancel', { target: b.dataset.cancel })));
      $('#intent-history tbody').innerHTML = v.history.length ? v.history.map(h => `<tr><td class="num">${clock(h.started_ts)}</td><td>${esc(h.label)}</td><td>${esc(h.target)}</td><td class="r num">${h.duration_s} s</td><td>${badge(h.status.toUpperCase(), STATUS_KIND[h.status] || 'muted')}</td></tr>`).join('')
        : '<tr><td colspan="5" class="muted">No intents yet.</td></tr>';
    }
    async function post(url, body) {
      err.hidden = true;
      const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const data = await res.json();
      if (!res.ok) { err.textContent = data.error || 'Request failed'; err.hidden = false; return; }
      render(data.active ? data : await getJSON('/api/intent'));
    }
    $('#intent-activate').addEventListener('click', () => post('/api/intent', {
      intent: $('#f-intent').value, target: $('#f-target').value, duration_seconds: parseInt($('#f-duration').value, 10) }));
    poll('/api/intent', render, 1000);
  }

  /* ---------------- Congestion ---------------- */
  function congestion() {
    const STATES = ['NORMAL', 'WARNING', 'CONGESTED', 'RECOVERING'];
    let th = null;
    function paint(v) {
      th = v.thresholds;
      $('#state-steps').innerHTML = STATES.map(s => `<div class="step ${s}${v.state === s ? ' on' : ''}">${s}</div>`).join('');
      const cap = v.capacity;
      $('#cg-facts').innerHTML = dl([
        ['Current state', stateBadge(v.state)],
        ['Time in state', isNil(v.duration_s) ? na() : f(v.duration_s, 0) + ' s'],
        ['Capacity', cap ? `${f(cap.mbps, 1)} Mbit/s <span class="badge warn">PLACEHOLDER</span>` : na('N/A — no estimate yet')],
        ['Demand', isNil(v.demand_mbps) ? na() : f(v.demand_mbps, 2) + ' Mbit/s (sum of class estimates)'],
        ['Utilisation', v.utilization && !isNil(v.utilization.value) ? `${f(v.utilization.value * 100, 0)}% of ${esc(v.utilization.basis.replace(/_/g, ' '))}` : na()]]);
      const names = { demand_ratio: ['Demand / capacity', ''], queue_delay_ms: ['Queue delay', 'ms'], loss_pct: ['Packet loss', '%'], rtt_inflation_ms: ['RTT inflation', 'ms'] };
      $('#sig-table tbody').innerHTML = Object.entries(th.signals).map(([k, t]) => {
        const val = v.signals[k], n = names[k] || [k, ''];
        return `<tr><td>${n[0]}</td><td class="r num">${isNil(val) ? na(k === 'queue_delay_ms' ? 'N/A — not measured' : 'N/A — unavailable') : f(val, 2) + ' ' + n[1]}</td><td class="r num">${t.warn}</td><td class="r num">${t.congested}</td></tr>`;
      }).join('');
      $('#cg-rules').textContent = `Hysteresis: exit below ${th.exit_factor * 100}% of entry threshold · sustained ticks: warn ${th.warn_ticks}, congested ${th.congest_ticks}, clear ${th.clear_ticks}, recover ${th.recover_ticks} · min dwell ${th.min_state_s}s, congested hold ${th.congested_hold_s}s.`;
      $('#cg-note').textContent = v.note;
      const body = $('#cg-history tbody');
      body.innerHTML = v.history.length ? v.history.map(h => `<tr><td class="num">${clock(h.ts)}</td><td>${stateBadge(h.previous)} → ${stateBadge(h.new)}</td><td class="wrap">${esc(h.reason.replace(/_/g, ' '))}</td><td class="r num">${isNil(h.capacity_mbps) ? na('N/A') : f(h.capacity_mbps, 1)}</td><td class="r num">${f(h.demand_mbps, 2)}</td><td class="muted num wrap">${esc(Object.entries(h.signals).map(([k, x]) => k + '=' + f(x, 2)).join(' '))}</td></tr>`).join('')
        : '<tr><td colspan="6" class="muted">No state transitions yet. The detector starts in NORMAL.</td></tr>';
    }
    poll('/api/congestion', paint, 1000);
  }

  /* ---------------- Safety ---------------- */
  function safety() {
    poll('/api/safety/detail', v => {
      const icon = ok => ok === null ? '<span class="ic na">–</span>' : ok ? '<span class="ic ok">✓</span>' : '<span class="ic bad">✗</span>';
      $('#safety-status').innerHTML = v.status === 'OK' ? badge('SAFE', 'ok') : v.status === 'VIOLATION' ? badge('VIOLATION', 'bad') : badge('N/A — no telemetry', 'muted');
      $('#safety-checks').innerHTML = v.checks.map(c => `<li>${icon(c.ok)}<span>${esc(c.label)}</span><span class="detail">${c.ok === null && c.detail.startsWith('N/A') ? na(esc(c.detail)) : esc(c.detail)}</span></li>`).join('');
      $('#safety-failures').innerHTML = v.recent_failures.length ? v.recent_failures.map(e => `<li><span class="t">${clock(e.ts)}</span><span class="bar ${e.level === 'danger' ? 'danger' : 'warn'}"></span><div><div class="title">${esc(e.title)}</div><div class="kv">${esc(Object.entries(e.detail || {}).map(([k, x]) => k + '=' + x).join('  '))}</div></div></li>`).join('')
        : '<li><span></span><span></span><div class="muted">No safety failures recorded.</div></li>';
    }, 2000);
  }

  /* ---------------- Rollback ---------------- */
  function rollback() {
    const tbl = (id, snap) => { $(id).innerHTML = snap ? U.snapRows(snap.classes, false) : '<tr><td colspan="6" class="muted">N/A — none</td></tr>'; };
    poll('/api/rollback', v => {
      $('#rb-status').innerHTML = dl([
        ['Rollback available', v.available ? badge('YES', 'ok') : badge('NO — no earlier policy', 'muted')],
        ['Last rollback', v.last_rollback ? clock(v.last_rollback.ts) : na('N/A — none has occurred')],
        ['Rollback reason', v.last_rollback ? esc(v.last_rollback.reason) : na('N/A')],
        ['Rollback status', v.last_rollback ? esc(v.status) : esc(v.status)],
        ['Scope', esc(v.note)]]);
      $('#rb-cur-meta').textContent = v.current ? `capacity ${f(v.current.capacity_mbps, 1)} Mbit/s` : 'no policy yet';
      $('#rb-lkg-meta').textContent = v.last_known_good ? `capacity ${f(v.last_known_good.capacity_mbps, 1)} Mbit/s` : 'none stored';
      tbl('#rb-cur tbody', v.current); tbl('#rb-lkg tbody', v.last_known_good);
    }, 2000);
  }

  /* ---------------- System ---------------- */
  function controller() {
    poll('/api/system/controller', v => {
      $('#ctl-facts').innerHTML = dl([
        ['Control loop', v.loop_running ? badge('RUNNING', 'ok') : badge('STOPPED', 'bad')],
        ['Loop interval', `${v.tick_seconds} s`], ['Ticks run', v.ticks],
        ['Last tick duration', isNil(v.last_tick_ms) ? na() : `${v.last_tick_ms} ms`],
        ['Uptime', `${f(v.uptime_s, 0)} s`], ['Congestion state', stateBadge(v.congestion_state)],
        ['Telemetry', v.telemetry_ok === null ? na('N/A — no sample yet') : v.telemetry_ok ? badge('OK', 'ok') : badge('UNAVAILABLE', 'bad')],
        ['Enforcement', badge(v.enforcement.mode, 'warn')]]);
      $('#ctl-components').innerHTML = v.components.map(c => `<li>${esc(c)}</li>`).join('');
    }, 2000);
  }
  function telemetry() {
    poll('/api/system/telemetry', v => {
      $('#tel-facts').innerHTML = dl([
        ['Source', esc(v.source)],
        ['Collection', v.collection_ok === null ? na('N/A — no sample yet') : v.collection_ok ? badge('OK', 'ok') : badge('FAILING', 'bad') + ' ' + esc(v.error || '')],
        ['Latest update', clock(v.latest_ts)], ['Interval', `${v.interval_s} s`],
        ['Probe', `${esc(v.probe.namespace)} → ${esc(v.probe.target)} · ${v.probe.running ? 'running' : 'not running'}`]]);
      $('#tel-metrics tbody').innerHTML = v.metrics.map(m => `<tr><td>${esc(m.metric)}</td><td class="wrap">${esc(m.source)}</td><td>${m.measured ? badge('MEASURED', 'ok') : badge('NOT MEASURED', 'muted')}</td></tr>`).join('');
    }, 2000);
  }
  function tc() {
    poll('/api/system/tc', v => {
      $('#tc-banner').textContent = v.message;
      $('#tc-banner').className = 'banner info static';
      $('#tc-banner').style.fontWeight = '600';
      $('#tc-facts').innerHTML = dl([
        ['Mode', badge(v.mode, 'ok')],
        ['tc backend implemented', badge('YES', 'ok')],
        ['Architecture', 'HTB hierarchical qdisc + FQ-CoDel leaf schedulers'],
        ['Observed interface', esc(v.observed_iface)],
        ['Network Namespace', esc(v.namespace || 'ns-router')],
        ['Shaping direction', esc(v.shaping_direction)],
        ['Filter mechanism', esc(v.filter_type || 'u32 match ip src')],
        ['Kernel Hierarchy', `${esc(v.parent_handle)} root -> ${esc(v.root_class)} parent -> 6 HTB leaf classes`],
        ['Root qdisc backlog', v.queue ? `${v.queue.backlog_packets} pkts / ${v.queue.backlog_bytes} B` : '0 pkts / 0 B'],
        ['Root qdisc drops', v.queue ? v.queue.dropped : '0 drops']
      ]);
      $('#tc-note').textContent = v.queue_note;
    }, 2000);
  }
  function experiments() {
    getJSON('/api/experiments').then(v => { $('#exp-msg').textContent = v.message; }).catch(() => {});
  }
  ({ intent, congestion, safety, rollback, controller, telemetry, tc, experiments }[page] || (() => {}))();
})();
