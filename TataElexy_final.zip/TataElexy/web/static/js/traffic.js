/* Live Traffic page: start/stop real iperf3 profiles and chart per-client throughput. */
(function () {
  const { CLASS_COLOR } = window.QOSUI;
  const names = ['gaming', 'call', 'stream', 'bulk'];
  const colors = ['#F0B44D', '#35C98A', '#4F8CFF', '#B49BFF'];
  const chart = QOSCharts.create('chart-clients', names.map((n, i) => ({
    key: n, label: n, color: colors[i],
    get: fr => (fr.clients.find(c => c.name === n) || { mbps: null }).mbps })), 'Mbit/s');
  QOS.on('frame', () => chart && chart.refresh());
  QOS.on('history', () => chart && chart.refresh());

  const err = document.getElementById('gen-error');
  function paint(list) {
    list.forEach(p => {
      const row = document.querySelector(`tr[data-profile="${p.name}"]`); if (!row) return;
      row.querySelector('.state').textContent = p.running ? `running · ${p.remaining_s}s left` : 'idle';
      row.querySelector('.act-start').disabled = p.running;
      row.querySelector('.act-stop').disabled = !p.running;
    });
  }
  async function refresh() { try { paint(await (await fetch('/api/traffic')).json()); } catch (e) { /* offline */ } }
  async function send(profile, action, duration) {
    err.hidden = true;
    const res = await fetch('/api/traffic', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ profile, action, duration }) });
    const body = await res.json();
    if (!res.ok) { err.textContent = body.error || 'Request failed'; err.hidden = false; }
    refresh();
  }
  document.querySelectorAll('#gen-table tbody tr').forEach(row => {
    const name = row.dataset.profile;
    row.querySelector('.act-start').addEventListener('click', () => send(name, 'start', parseInt(row.querySelector('input').value, 10)));
    row.querySelector('.act-stop').addEventListener('click', () => send(name, 'stop'));
  });
  refresh(); setInterval(refresh, 2000);
})();
