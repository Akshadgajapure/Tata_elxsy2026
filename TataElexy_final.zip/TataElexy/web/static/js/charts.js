/* Chart.js helpers. Data comes only from QOS.frames (backend telemetry). */
(function () {
  Chart.defaults.color = '#8A98A7';
  Chart.defaults.font.family = 'Inter, system-ui, sans-serif';
  Chart.defaults.borderColor = '#202B36';
  const WINDOW = 60;

  function labels(n) { return Array.from({ length: n }, (_, i) => (i - n + 1) + 's'); }

  function create(canvasId, seriesDefs, unit) {
    const el = document.getElementById(canvasId);
    if (!el) return null;
    const chart = new Chart(el, {
      type: 'line',
      data: { labels: labels(WINDOW), datasets: seriesDefs.map(s => ({
        label: s.label, borderColor: s.color, backgroundColor: s.color, borderWidth: s.key === 'total' ? 2 : 1.5,
        pointRadius: 0, tension: 0.2, borderDash: s.dash || [], hidden: s.hidden || false, data: [] })) },
      options: {
        animation: false, responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
        scales: {
          x: { grid: { display: false }, ticks: { maxTicksLimit: 7 } },
          y: { beginAtZero: true, title: { display: true, text: unit }, ticks: { font: { family: 'JetBrains Mono, monospace' } } },
        },
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => `${c.dataset.label}: ${(c.parsed.y ?? 0).toFixed(2)} ${unit}` } } },
      },
    });
    chart.refresh = function () {
      const frames = QOS.frames.slice(-WINDOW);
      const pad = WINDOW - frames.length;
      chart.data.datasets.forEach((ds, i) => {
        ds.data = Array(pad).fill(null).concat(frames.map(f => seriesDefs[i].get(f)));
      });
      chart.update('none');
    };
    return chart;
  }
  window.QOSCharts = { create };
})();
